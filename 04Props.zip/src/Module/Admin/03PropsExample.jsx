import React from 'react';
import CardCompo from './04CardComponent.jsx';
import CardCompoChildren from './05CardCompoChildren.jsx';

const PropsExample = () => {

    fetch("https://fakestoreapi.com/products/").then((response) => response.json()).then((result) => {
        console.log(result);
    })


    return (
        <div>
            props Examples
            <section class="py-2">
                <div class="container px-4 px-lg-5 mt-5">
                    <div class="row ">
                        <div class="col-3 mb-5"><CardCompo productTitle="Product Testing" /></div>
                        <div class="col-3 mb-5"><CardCompo productTitle="Product Something" /></div>
                        <div class="col-3 mb-5"><CardCompo productTitle="Product Data" /></div>
                        <div class="col-3 mb-5"><CardCompo productTitle="<h2>Product Checking</h2>" /></div>
                        {/* <div class="col-3 mb-5"><CardCompo productTitle=<h2>Product Checking</h2>/></div> */}

                        <div class="col-3 mb-5">
                            <CardCompoChildren productTitle="children">
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center">
                                    <a class="btn btn-outline-dark mt-auto" href="#" role="button"><span class="bi bi-cart4"></span> Add to cart</a>
                                </div>
                            </div>
                        </CardCompoChildren></div>
                    </div>
                </div>
            </section>

        </div>
    );
};

export default PropsExample;