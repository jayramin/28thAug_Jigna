import React,{ useEffect,useState } from 'react';

const UseEffectExample = () => {
    let [counter,setAnything] = useState(0)
    let [kaipan,bijukai] = useState(true)
    let [apiData,setAPIData] = useState(0)


    // useEffect(()=>{
    //     console.log("called useEffect simple");
    // })
    let decrement = ()=>{
        setAnything(counter-1)
        setAPIData(10000)
    }
    // useEffect(()=>{
    //     console.log("single calling with empty dependency");
    // },[])
    // useEffect(()=>{
    //     console.log("single calling with empty dependency");
    // },[counter])
    useEffect(()=>{
        console.log("single calling with empty dependency");
        return (()=>{
            setAPIData(null)
            console.log("component leave");
            // cleanup method
        })
    },[counter])
    return (
        <>
          UseEffectExample  
          <button onClick={decrement}>-</button>
            {counter}
            <button onClick={()=>{setAnything(counter+1)}}>+</button>
            <button onClick={()=>{bijukai(!kaipan)}}>{JSON.stringify(kaipan)}</button>

        </>
    );
};

export default UseEffectExample;