import React from 'react';

const CardComponent = (props) => {
    return (
        <>
            {/* {JSON.stringify(abc)} */}
                <div class="card h-100">
                    <div class="badge bg-danger text-white position-absolute mt-1 ms-1">Sale</div>
                    <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..." />
                    <div class="card-body text-center">
                        <a href="#" class="h4 text-primary text-decoration-none">{props.productTitle}</a>
                        <div class="d-flex justify-content-center small text-warning my-2">
                            <div class="bi-star-fill"></div>
                            <div class="bi-star-fill"></div>
                            <div class="bi-star-fill"></div>
                            <div class="bi-star-half"></div>
                            <div class="bi-star"></div>
                        </div>
                        <div class="product-price">
                            <span class="text-muted text-decoration-line-through price-old">$20.55</span>
                            <span class="price fw-bold ms-2">$18.55</span>
                        </div>
                    </div>
                    <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                        <div class="text-center">
                            <a class="btn btn-outline-dark mt-auto" href="#" role="button"><span class="bi bi-cart4"></span> Add to cart</a>
                        </div>
                    </div>
                </div>
        </>
    );
};

export default CardComponent;