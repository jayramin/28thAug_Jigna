import React, { useState } from 'react';

const UseStateExample = () => {
    let [counter,setAnything] = useState(0)
    let [kaipan,bijukai] = useState(true)

    let abc = "something"
    let decrement = ()=>{
        setAnything(counter-1)
    }
    return (
        <div>
            <button onClick={() => {
                console.log("called");
                abc = "other data"
            }}>Click</button>
            {/* <button onClick={()=>{abc="other data"}}>Click</button> */}
            use state Example

            <p>variable abc data = {abc}</p>
            {/* <button onClick={decrement()}>-</button> */}
            <button onClick={decrement}>-</button>
            {counter}
            <button onClick={()=>{setAnything(counter+1)}}>+</button>
            <button onClick={()=>{bijukai(!kaipan)}}>{JSON.stringify(kaipan)}</button>

        </div>
    );
};

export default UseStateExample;