import { Outlet, useRoutes } from "react-router-dom"
import AdminLayout from "./AdminLayout.jsx"
import UseStateExample from "./01UseStateExample.jsx"
import UseEffectExample from "./02UseEffectExample.jsx"



const AdminRoute = () => {
    const routes = useRoutes([
        {
            path: "/",
            element: <><AdminLayout/></>,
            children: [
                {
                    path: "profile",
                    element: <>Profile Data</>,
                },{
                    path: "dashboard",
                    element: <>Profile Data</>,
                },{
                    path: "usestateexample",
                    element: <UseStateExample/>,
                },{
                    path: "useeffectexample",
                    element: <UseEffectExample/>,
                }
            ]
        }])
    return routes
}
export default AdminRoute;