import React from 'react';
import ReactDOM from 'react-dom/client';
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import "@fortawesome/fontawesome-free/css/all.min.css";

const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render( "test" );
// root.render( <div> <h2>Test</h2><h2>Test</h2></div> );
// root.render( <><h2>Test</h2><h2>Test</h2></> );
// root.render( mainCompo() );
// root.render( <mainCompo></mainCompo> );
// root.render( <mainCompo/> ); // Warning: <mainCompo /> is using incorrect casing. Use PascalCase for React components, or lowercase for HTML elements.
// let MainCompo = ()=> {
//   return <><h2>Test</h2><h2>Test</h2></>
// }
// root.render( <MainCompo/> ); // Warning: <mainCompo /> is using incorrect casing. Use PascalCase for React components, or lowercase for HTML elements.

// root.render( <h2>Test</h2><h2>Test</h2> );
// function MainCompo() {
//   return <><h2>Test</h2><h2>Test</h2></>
// }
// root.render( <MainCompo/> ); // Warning: <mainCompo /> is using incorrect casing. Use PascalCase for React components, or lowercase for HTML elements.