import React from 'react';

const Contactus = () => {
    return (
        <>
          <h2>Contact us page data</h2>  
        </>
    );
};

export default Contactus;