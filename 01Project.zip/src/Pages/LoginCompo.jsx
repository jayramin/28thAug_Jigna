import React from 'react';
import { Link } from 'react-router-dom';
import ValidateInput from './../CustomHook/Validate';
const LoginCompo = () => {
    // const {InputChangeHandle,inp,errors}=ValidateInput({},{});
    const [emptyData, setEmptyData] = useState(false);
    const { InputChangeHandle, inp, errors } = ValidateInput({}, {});
    let checkLogin = () => {
        if (Object.keys(inp).length == 0) {
            setEmptyData(!emptyData)
        } else {

            if (inp.uname == "" || inp.pass == "" || inp.email == "" || inp.mobile == "") {
                // console.log(errors);
                setEmptyData(!emptyData)
            } else {
                setEmptyData(!emptyData)
                // fetch(`http://localhost:5000/users?`)
                fetch(`http://localhost:5000/users?uname=${inp.name}&pass=${inp.name}`)

                // localStorage.setItem('token', response.data.token);
                // import Cookies from 'universal-cookie';
                // const cookies = new Cookies();
                // cookies.set('myCat', 'Pacman', { path: '/' });
                // console.log(cookies.get('myCat')); // Pacman
            }
        }
    }
    return (
        <>
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-4 offset-lg-4">
                        <div className="card">
                            <div className="card-header text-center">Login</div>
                            {/* <div className="card-body">  </div>    */}
                            <div className="card-body">
                                <form onSubmit={checkLogin}>
                                    <div className="row">
                                        <div className="col">
                                            <input type="text" placeholder='Enter User Name' className='form-control' onChange={InputChangeHandle} name="uname" onBlur={InputChangeHandle} required />
                                            {errors.unameError ? <span>This field is Required</span> : <></>}
                                        </div>

                                    </div>
                                    <div className="row mt-3">
                                        <div className="col">
                                            <input className='form-control' placeholder='Enter your Password' type="password" onChange={InputChangeHandle} name="pass" onBlur={InputChangeHandle} required />
                                            {errors.unameError ? <span>This field is Required</span> : <></>}
                                        </div>

                                    </div>
                                    <div className="row mt-3">
                                        <div className="col text-center">
                                            <input type="submit" className='btn btn-info' /> &nbsp;
                                            <input type="reset" className='btn btn-warning' />
                                        </div>

                                    </div>
                                </form>
                                <div className="row mt-3">
                                    <div className="col text-center">
                                        <Link to="/signup">Click here to create new account</Link>
                                    </div>
                                </div>
                                <div className="row mt-3">
                                    <div className="col text-center">
                                        {(emptyData) ? "* fields are required" : ""}
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default LoginCompo;